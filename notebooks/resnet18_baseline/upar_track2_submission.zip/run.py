"""UPAR 2027 Track 2 inference entry point."""
from pathlib import Path

import numpy as np
import torch
from PIL import Image
from torch import nn
from torchvision import models, transforms

HERE = Path(__file__).resolve().parent
MODEL = None
ATTRIBUTE_NAMES = None
TRANSFORM = None
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def load_model():
    global MODEL, ATTRIBUTE_NAMES, TRANSFORM
    checkpoint = torch.load(HERE / "assets/upar_track2_best.pth", map_location="cpu", weights_only=True)
    ATTRIBUTE_NAMES = checkpoint["attribute_names"]
    size = tuple(checkpoint["image_size"])
    TRANSFORM = transforms.Compose([
        transforms.Resize(size),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
    ])
    model = models.resnet18(weights=None)
    model.fc = nn.Linear(model.fc.in_features, 40)
    model.load_state_dict(checkpoint["state_dict"])
    MODEL = model.to(DEVICE).eval()


def rank_gallery(sample):
    if MODEL is None:
        load_model()
    order = [ATTRIBUTE_NAMES.index(name) for name in sample["attribute_names"]]
    gallery = sample["gallery"]
    queries = np.asarray(sample["queries"], dtype=np.float32)
    scores = np.empty((len(queries), len(gallery)), dtype=np.float32)
    batch_size = 128
    with torch.inference_mode():
        for start in range(0, len(gallery), batch_size):
            batch = gallery[start:start + batch_size]
            images = []
            for entry in batch:
                with Image.open(entry["image_path"]) as image:
                    images.append(TRANSFORM(image.convert("RGB")))
            logits = MODEL(torch.stack(images).to(DEVICE))
            probabilities = logits.sigmoid().float().cpu().numpy()[:, order]
            # L1 distance from each binary query to each predicted attribute vector.
            distances = probabilities.sum(axis=1)[None, :] + queries @ (1.0 - 2.0 * probabilities).T
            scores[:, start:start + len(batch)] = distances
    return {"distances": scores}
